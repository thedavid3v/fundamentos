import { Alert, Container } from "react-bootstrap";
import Cabecalho from "../components/Cabecalho";

export default function Fundamentos(){



    return (
        <>
            <Cabecalho />

           <Container>
                <Alert>
                    Atenção! Preste muita atenção.
                </Alert>
            <h1>Fundamentos</h1>
            <p>Sucesso</p>
           
            <Cabecalho />
            </Container>
        </>
    )    
}


