export default function Cabecalho(){
    return (
        <>
            <div>
                <h1>Cabeçalho</h1>
                <p>Isto é o cabeçalho da minha página</p>
            </div>
        </>
    )
}